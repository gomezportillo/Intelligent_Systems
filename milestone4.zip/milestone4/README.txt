#******************************************************
#*********************  README  ***********************
#******************************************************

Python program to generate a graph into a hash table from
a .osm file and work within it.

#****** AUTHORS

Juan Garrido Arcos 
    - juan.garrido3@alu.uclm.es
    
Pedro-Manuel Gómez-Portillo López 
    - pedromanuel.gomezportillo@alu.uclm.es

